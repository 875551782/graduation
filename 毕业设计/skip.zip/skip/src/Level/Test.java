package Level;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
public class Test {
	
	public static void main(String[] args) throws Exception {
		String filePath = "X:\\hash";
		File file = new File(filePath);
		SkipList skip = new SkipList();
		/*long i=0l;
		if(file.isDirectory()) {
			for(File value :file.listFiles()) {
				i=i+1;
				skip.add_NodeByValue(i,getMD5Checksum(value));
			}
		}
		//File file1 = new File("X:\\hash\\a.txt");
		
		
		skip.print();
		
		System.out.println(skip.getHash(3L));*/
		System.out.println(getMD5Checksum(new File("x:\\hash\\a.txt")));
	}
		
	public static byte[] createChecksum(File file) throws Exception {
        InputStream fis =  new FileInputStream(file);
        byte[] buffer = new byte[1024];
        MessageDigest complete = MessageDigest.getInstance("MD5");//Java Security name (such as "SHA", "MD5", and so on).
        int numRead;

        do {
            numRead = fis.read(buffer);
            if (numRead > 0) {
                complete.update(buffer, 0, numRead);
            }
        } while (numRead != -1);

        fis.close();
        return complete.digest();
    }

	public static String getMD5Checksum(File file) throws Exception {
        byte[] b = createChecksum(file);
        String result = "";
        for (int i=0; i < b.length; i++) {
            result += Integer.toString( ( b[i] & 0xff ) + 0x100, 16).substring( 1 );
        }
        return result;
    }
	
	
}
