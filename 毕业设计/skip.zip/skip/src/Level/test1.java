package Level;

public class test1 {

	public static void main(String[] args) {
		String str = "e2fc714c4727ee9395f324cd2e7f331f";
		System.out.println(str.substring(16));
		long i = Long.parseLong("e2fc714c", 16);
		System.out.println(i);
	}
}
