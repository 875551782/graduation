package Level;

import java.math.BigInteger;
import java.util.Random;

public class SkipList {
	private Integer level = 3;
	
	private SkipListNode head;
	private SkipListNode tail;
	private final Long MIN = -9223372036854775808L;
	private final Long MAX = 9223372036854775806L;
	
	private SkipListNode[] current;
	
	
	
	private Random rand = new Random();
	
	public String sumHash(String value1,String value2) {
		String value11 = value1.substring(0,8);
		String value12 = value1.substring(8,16);
		String value13 = value1.substring(16,24);
		String value14 = value1.substring(24);
		String value21 = value2.substring(0,8);
		String value22 = value2.substring(8,16);
		String value23 = value1.substring(16,24);
		String value24 = value1.substring(24);
		long h1 = Long.parseLong(value11,16)|Long.parseLong(value21,16);
		long h2 = Long.parseLong(value12,16)|Long.parseLong(value22,16);
		long h3 = Long.parseLong(value13,16)|Long.parseLong(value23,16);
		long h4 = Long.parseLong(value14,16)|Long.parseLong(value24,16);
		String str1 = Long.toHexString(h1);
		String str2 = Long.toHexString(h2);
		String str3 = Long.toHexString(h3);
		String str4 = Long.toHexString(h4);
		return str1+str2+str3+str4;
	}
	
	public SkipList() {
		head = new SkipListNode(MIN,new Object(),level);
		tail = new SkipListNode(MAX,new Object(),level);
		current = new SkipListNode[level];
		for(int i = level-1;i>=0;i--) {
			
			head.getForword()[i] = tail;
			tail.getBack()[i] = head;
			
		}
		
	}
	
	public SkipList(int level) {
		this.level = level;
		head = new SkipListNode(MIN,new Object(),level);
		tail = new SkipListNode(MAX,new Object(),level);
		for(int i = level-1;i>=0;i--) {
			
			head.getForword()[i] = tail;
			tail.getBack()[i] = head;
		}
		
	}
	/**
	 * ����value���ҽڵ㣨���û���򷵻�����valueֵ�����ǰһ���ڵ㣩
	 * @param value
	 * @return
	 */
	public SkipListNode find(Long key) {
		int i = level-1;
		SkipListNode node = head;
		while(i!=-1) {
			while(node.getForword()[i].getKey()<=key) {
				node = node.getForword()[i];	
			}
			i--;
		}
		return node;
		
	}
	
	public boolean isExsit(Long key) {
		
		SkipListNode node = find(key);
		if(node.getKey()-key!=0) {
			return false;
		}
		return true;
		
	}
	
	public String getHash(Long key) {
		SkipListNode node = find(key);
		String value = node.getValue().toString();
		String hash=value;
		while(node.getForword()[0].getKey()-MAX!=0) {
			String value1 = node.getForword()[0].getValue().toString();
			hash = sumHash(hash, value1);
			node = node.getForword()[0];
		}
		return hash;
	}
	
	public boolean isChanage(Long key,Object value) {
		SkipListNode node = find(key);
		if(node.getValue()!=value) {
			return true;
		}
		return false;
	}
	
	private void add_Node(Long key,Object value) {
		if(isExsit(key)) {
			return;
		}
		SkipListNode addNode = new SkipListNode(key,value,level);
		SkipListNode node = find(key);
		for(int i = 0;i<=level-1;i++) {
			SkipListNode next = node.getForword()[i];
			SkipListNode pre = next.getBack()[i];
			addNode.getForword()[i] = next;
			addNode.getBack()[i] = pre;
		}
		for(int i = 0;i<=level-1;i++) {
			SkipListNode next = node.getForword()[i];
			SkipListNode pre = next.getBack()[i];
			double num = rand.nextDouble();
			if(i==0) {
				pre.getForword()[i] = addNode;
				next.getBack()[i] = addNode;
			}
			else if(i>0&&num>0.5) {
				pre.getForword()[i] = addNode;
				next.getBack()[i] = addNode;
			}
			else {
				break;
			}
		}
		
	}

	public void add_NodeByValue(Long key,Object value) {
		add_Node(key,value);
	}
	
/*	public void add_Tail(Integer value) {
		add_Node(value,tail);
		
	}*/
	
	public void delete_NodeByValue(Long key,Object value) {
		if(!isExsit(key)) {
			return;
		}
		
		SkipListNode node = find(key);
		for(int i =0;i<3;i++) {
			SkipListNode pre = node.getBack()[i];
			SkipListNode next = node.getForword()[i];
			pre.getForword()[i] = next;
			next.getBack()[i] = pre;
			
		}
	}
	
	public void change_Value(Long key,Object value) {
		if(!isExsit(key)) {
			return;
		}
		
		SkipListNode node = find(key);
		node.setValue(value);
	}
	
	public void print() {
		SkipListNode skipListNode;
		for(int i=0;i<level;i++) {
			skipListNode = this.getHead();
			System.out.println("第"+i+"层");
			//System.out.println(skipListNode.getForword()[i].getForword()[i].getValue());
			while(skipListNode.getForword()[i].getKey()!=MAX ) {
				skipListNode = skipListNode.getForword()[i];
				System.out.print("label:"+skipListNode.getKey());
				System.out.println(";value:"+skipListNode.getValue()+"==》");
				
			}
			System.out.println();
		}
	}
	public SkipListNode getHead() {
		return head;
	}


	public void setHead(SkipListNode head) {
		this.head = head;
	}


	public SkipListNode getTail() {
		return tail;
	}


	public void setTail(SkipListNode tail) {
		this.tail = tail;
	}


	public SkipListNode[] getCurrent() {
		return current;
	}


	public void setCurrent(SkipListNode[] current) {
		this.current = current;
	}


	public Random getRand() {
		return rand;
	}


	public void setRand(Random rand) {
		this.rand = rand;
	}

	
}
