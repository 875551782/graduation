package Level;

import java.util.HashMap;

public class SkipListNode implements Comparable{
	private Long key;
	//��ǰ�ڵ��ֵ
	private Object value;
	
	private SkipListNode[] forword;
	private SkipListNode[] back;
	
	
	

	public SkipListNode(Long key,Object value,Integer level) {
		this.key = key;
		this.value = value;
		this.forword = new SkipListNode[level];
		this.back = new SkipListNode[level];
	}
	
	public SkipListNode(Integer value) {
		this.value = value;
	}
	
	
	public SkipListNode[] getForword() {
		return forword;
	}

	public void setForword(SkipListNode[] forword) {
		this.forword = forword;
	}

	
	public SkipListNode[] getBack() {
		return back;
	}

	public void setBack(SkipListNode[] back) {
		this.back = back;
	}

	
	public Long getKey() {
		return key;
	}

	public void setKey(Long key) {
		this.key = key;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	@Override
	public int compareTo(Object o) {
		SkipListNode skipListNodes = (SkipListNode) o;
		if(this.getKey()>skipListNodes.getKey()) {
			return 1;
		}
		else if(this.getKey()==skipListNodes.getKey()){
			return 0; 
		}
		else {
			return -1;
		}
		
	}
	

	
	

}
