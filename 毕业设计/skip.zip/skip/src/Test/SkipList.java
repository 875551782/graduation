package Test;

import java.util.Random;

public class SkipList {
	private Integer level = 3;
	
	private SkipListNode head;
	private SkipListNode tail;
	
	
	private SkipListNode[] current;
	
	private double n=0.5;
	
	private Random rand = new Random();
	
	private int sum=0;
	private int time=0;
	
	public SkipList() {
		head = new SkipListNode(-1000000,level);
		tail = new SkipListNode(1000000,level);
		current = new SkipListNode[level];
		for(int i = level-1;i>=0;i--) {
			
			head.getForword()[i] = tail;
			tail.getBack()[i] = head;
			
		}
		
	}

	public SkipList(int level) {
		this.level = level;
		head = new SkipListNode(-1000000,level);
		tail = new SkipListNode(1000000,level);
		for(int i = level-1;i>=0;i--) {
			
			head.getForword()[i] = tail;
			tail.getBack()[i] = head;
		}
		
	}
	/**
	 * ����value���ҽڵ㣨���û���򷵻�����valueֵ�����ǰһ���ڵ㣩
	 * @param value
	 * @return
	 */
	public SkipListNode find(Integer value) {
		
		int i = level-1;
		SkipListNode node = head;
		while(i!=-1) {
			while(node.getForword()[i].getValue()<=value) {
				node = node.getForword()[i];
				time++;
			}
			i--;
		}
		return node;
	}
	
	public boolean isExsit(Integer value) {
		SkipListNode node = find(value);
		if(node.getValue()-value!=0) {
			return false;
		}
		return true;
		
	}
	
	
	private void add_Node(Integer value) {
		if(isExsit(value)) {
			return;
		}
		SkipListNode addNode = new SkipListNode(value,level);
		SkipListNode node = find(value);
		for(int i = 0;i<=level-1;i++) {
			SkipListNode next = node.getForword()[i];
			SkipListNode pre = next.getBack()[i];
			addNode.getForword()[i] = next;
			addNode.getBack()[i] = pre;
		}
		for(int i = 0;i<=level-1;i++) {
			SkipListNode next = node.getForword()[i];
			SkipListNode pre = next.getBack()[i];
			double num = rand.nextDouble();
			if(i==0) {
				pre.getForword()[i] = addNode;
				next.getBack()[i] = addNode;
			}
			else if(i>0&&num<n) {
				pre.getForword()[i] = addNode;
				next.getBack()[i] = addNode;
				sum++;
			}
			else {
				break;
			}
		}
		
	}

	public void add_NodeByValue(Integer value) {
		add_Node(value);
	}
	
/*	public void add_Tail(Integer value) {
		add_Node(value,tail);
		
	}*/
	
	public void delete_NodeByValue(Integer value) {
		if(!isExsit(value)) {
			return;
		}
		
		SkipListNode node = find(value);
		for(int i =0;i<3;i++) {
			SkipListNode pre = node.getBack()[i];
			SkipListNode next = node.getForword()[i];
			pre.getForword()[i] = next;
			next.getBack()[i] = pre;
			
		}
	}
	
	public void change_Value(Integer value1,Integer value2) {
		if(!isExsit(value1)) {
			return;
		}
		
		SkipListNode node = find(value1);
		node.setValue(value2);
	}
	
	
	public void print() {
		SkipListNode skipListNode;
		for(int i=0;i<level;i++) {
			skipListNode = this.getHead();
			System.out.println("第"+i+"条");
			//System.out.println(skipListNode.getForword()[i].getForword()[i].getValue());
			while(skipListNode.getForword()[i].getValue()!=10000 ) {
				skipListNode = skipListNode.getForword()[i];
				System.out.print(skipListNode.getValue()+"==>>");
				
			}
			System.out.println();
		}
	}
	public SkipListNode getHead() {
		return head;
	}


	public void setHead(SkipListNode head) {
		this.head = head;
	}


	public SkipListNode getTail() {
		return tail;
	}


	public void setTail(SkipListNode tail) {
		this.tail = tail;
	}


	public SkipListNode[] getCurrent() {
		return current;
	}


	public void setCurrent(SkipListNode[] current) {
		this.current = current;
	}


	public Random getRand() {
		return rand;
	}


	public void setRand(Random rand) {
		this.rand = rand;
	}

	public double getN() {
		return n;
	}

	public void setN(double n) {
		this.n = n;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	
}
