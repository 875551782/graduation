package Test;

import java.util.HashMap;

public class SkipListNode implements Comparable{
	//��ǰ�ڵ��ֵ
	private Integer value;
	private SkipListNode[] forword;
	private SkipListNode[] back;
	
	
	

	public SkipListNode(Integer value,Integer level) {
		this.value = value;
		this.forword = new SkipListNode[level];
		this.back = new SkipListNode[level];
	}
	
	public SkipListNode(Integer value) {
		this.value = value;
	}
	
	
	public SkipListNode[] getForword() {
		return forword;
	}

	public void setForword(SkipListNode[] forword) {
		this.forword = forword;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}
	
	public SkipListNode[] getBack() {
		return back;
	}

	public void setBack(SkipListNode[] back) {
		this.back = back;
	}

	@Override
	public int compareTo(Object o) {
		SkipListNode skipListNodes = (SkipListNode) o;
		if(this.getValue()>skipListNodes.getValue()) {
			return 1;
		}
		else if(this.getValue()==skipListNodes.getValue()){
			return 0; 
		}
		else {
			return -1;
		}
		
	}
	

	
	

}
